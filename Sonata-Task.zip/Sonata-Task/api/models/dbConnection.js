const mysql = require('mysql');

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: process.env.MYSQL_DB_PW,
    database: process.env.DB
});
connection.connect((error) => {
    if(!error) {
        console.log("Database connected.");
    } else {
        console.log("Database not connected.");
    }
});

module.exports = connection;
