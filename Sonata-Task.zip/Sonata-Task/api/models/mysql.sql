CREATE DATABASE talent_acquisition;

CREATE TABLE `candidate_summary` (
  `candidate_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `experience` int(3) NOT NULL,
  `ctc_currency` varchar(10) NOT NULL,
  `ctc` int(4) NOT NULL,
  `ctc_type` varchar(10) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `phone_number` varchar(100) NOT NULL,
  `linkedInLink` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `candidates_data` text NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
