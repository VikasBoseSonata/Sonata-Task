CREATE DATABASE talent_acquisition;

-- \c to move inside of the DB
CREATE TABLE talent_acquisition.candidate_summary (
    candidate_id bigserial NOT NULL,
    name varchar(100) NOT NULL,
    email_id varchar(100) NOT NULL,
    phone_number varchar(100) NOT NULL,
    candidates_data jsonb NULL,
    created_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    created_by varchar(100) NOT NULL,
    modified_date timestamp NULL,
    modified_by varchar(100) NULL,
    CONSTRAINT candidate_summary_pkey PRIMARY KEY (candidate_id)
);
