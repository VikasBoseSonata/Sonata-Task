// This route file will read the excel file and insert the data into postgre/mysql DB
const express = require('express');
const conn = require('../models/dbConnection');
const Validator = require("fastest-validator"); //This will use to validate the datatype while insert the data into DB
const xlsx = require('xlsx');
const validator = require('mysql-validator');

const route = express.Router();
const vali = new Validator();

const insertData = function(req, res) {
    var workbook = xlsx.readFile('files/candidate-upload-template-old.xlsx');
    /*var sheet_name_list = workbook.SheetNames;
    var xlData = xlsx.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);*/
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];
    
    const posts = [];
    let post = {};
    for(let cell in worksheet) {
        const cellAsString = cell.toString();
        if(cellAsString[1]!=='r' && cellAsString!='m' && cellAsString[1] > 1) {
            if(cellAsString[0] === 'A'){
                post.name = worksheet[cell].v;
            }
            if(cellAsString[0] === 'B'){
                post.designation = worksheet[cell].v;
            }
            if(cellAsString[0] === 'C'){
                post.company = worksheet[cell].v;
            }
            if(cellAsString[0] === 'D'){
                post.experience = worksheet[cell].v;
            }
            if(cellAsString[0] === 'E'){
                post.ctc_currency = worksheet[cell].v;
            }
            if(cellAsString[0] === 'F'){
                post.ctc = worksheet[cell].v;
            }
            if(cellAsString[0] === 'G'){
                post.ctc_type = worksheet[cell].v;
            }
            if(cellAsString[0] === 'H'){
                post.email_id = worksheet[cell].v;
            }
            if(cellAsString[0] === 'I'){
                post.phone_number = worksheet[cell].v;
            }
            if(cellAsString[0] === 'J'){
                post.linkedInLink = worksheet[cell].v;
            }
            if(cellAsString[0] === 'K'){
                post.location = worksheet[cell].v;
            }
            if(cellAsString[0] === 'L'){
                post.created_date = worksheet[cell].v;
            }
            if(cellAsString[0] === 'M'){
                post.created_by = worksheet[cell].v;
            }
            if(cellAsString[0] === 'N'){
                post.modified_date = worksheet[cell].v;
            }
            if(cellAsString[0] === 'O'){
                post.modified_by = worksheet[cell].v;
                posts.push(post);
                post = {};               
            }
        }
    }

    const schemaValidation = [{
        name: { type: "string", optional:false, min: 10, max: 100 },
        designation: { type: "string", optional:false, max: 100 },
        company_name: { type: "string", optional:false, max: 100 },
        experience: { type: "number", optional:true, min: 1, max: 50 },
        ctc_currency: { type: "string", min: 3, max: 10 },
        ctc: { type: "number", min: 10, max: 1000 },
        ctc_type: { type: "string", min: 3, max: 10 },
        email_id: { type: "email", optional:false, min: 10, max: 100 },
        phone_number: { type: "string", optional:false, max: 20 },
    }];

   
    /*const validationResponse = vali.validate(posts, schemaValidation);
    if(validationResponse !== true) {
        return res.status(400).json({
            message: "Validation failed.",
            error: validationResponse
        });
    } else {
        console.log(posts);
    }*/
   
    
    if(posts.length > 0 ){
       /*let sql = "INSERT INTO candidate_summary (name, designation, company_name, experience, ctc_currency, ctc, ctc_type, email_id, phone_number, linkedInLink, location) VALUE ";
        for(let i=0; i < posts.length; i++) {
            sql += "( "+ posts[i].name +","+ posts[i].designation +","+ posts[i].company +","+ posts[i].experience +","+ posts[i].ctc_currency +","+
               posts[i].ctc +","+ posts[i].ctc_type +","+ posts[i].email_id +","+ posts[i].phone_number +","+ posts[i].linkedInLink +","+ posts[i].location +")";
            if(posts.length > 1) {
                sql += ',';
            }
        }
        conn.query(sql, (error, result) => {
            if(error) {
                console.log(error);
                res.status(200).send({message: 'Data got failed.'})
            } else {
                console.log(data);
                res.status(200).send({message: 'Data inserted sucessfully.'});
            }
        });*/
        // we'll store all validation errors here
        var errors = [];
        // field-type mapping (this may be the result of 'describe table')
        var types = {
            name: 'varchar(100)',
            designation: 'varchar(100)',
            company_name: 'varchar(100)',
            experience: 'int(3)',
            ctc_currency: 'varchar(10)',
            ctc: 'varchar(2)',
            ctc_type: 'varchar(10)',
            email_id: 'varchar(100)',
            phone_number: 'varchar(100)',
            linkedInLink: 'varchar(100)',
            location: 'varchar(100)'
        }
        // loop through the submitted fields and validate them
        for (var key in req.body) {
            var err = validator.check(req.body[key], types[key]);
            // store the error's message and the field name
            if (err) errors.push({ name: key, error: err.message });
        }
        if (errors.length) {
            // notify the user about the errors
            res.render('template', { err: errors, other: 'params...' });
          } else {
            // safely store the user's input into the database
          }

        /*for(let i in posts) {
            for (var key in posts[i]) {
                // console.log(posts[i][key], types[key]);
                var err = validator.check(posts[i][key], types[key]);
                // store the error's message and the field name
                if (err) errors.push({ name: key, error: err.message });
            }
        }*/
    }
}

route.get('/', (req, res, next) => {
    conn.query("SELECT * FROM candidate_summary", (error, rows, fields) => {
        if(error) {
            res.status(400).json({
                message: "No data found."
            });
        } else {
            res.status(200).json({
                message: "Display all data."
            });
        }
    });    
});

route.post('/insertExcelData', (req, res, next) => {
  insertData(req, res);
  /*res.status(200).json({
      message: "Excel file uploaaded sucessfully."
  });*/
});

module.exports = route;
