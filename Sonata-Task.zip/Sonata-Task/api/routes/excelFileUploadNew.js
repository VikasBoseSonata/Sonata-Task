// This route file will read the excel file and insert the data into postgre/mysql DB
const express = require('express');
const conn = require('../models/dbConnection');

//This will use to validate the datatype while insert the data into DB
const Validator = require("fastest-validator");
const xlsx = require('read-excel-file/node');
const md5 = require('md5');

const route = express.Router();
const vali = new Validator();

const findDuplicateValue = function(rows) {
   var hashes = {};
   let flag = false;

   rows.forEach(function(row, idx){
        let checkDup = row[0].concat(row[7], row[8]);
        var hash = md5(checkDup);
        console.log(hash);
        if (hash in hashes) {
            hashes[hash].push(idx);
        } else {
            hashes[hash] = [idx];
        }
    });

    Object.keys(hashes).forEach(function(key, idx) {
        if (hashes[key].length > 1) {
            flag = true;
        }
    });
  return flag;
}
const insertData = function(req, res) {
    let a = xlsx('files/candidate-upload-template-new.xlsx').then((rows) => {
        const posts = [];
        const err = [];
        let post = {};
        
        for(let i=0; i<rows.length; i++) {
            post.name = rows[i][0];
            post.designation = rows[i][1];
            post.company_name = rows[i][2];
            post.experience = rows[i][3];
            post.ctc_currency = rows[i][4];
            post.ctc = rows[i][5];
            post.ctc_type = rows[i][6];
            post.email_id = rows[i][7];
            post.phone_number = rows[i][8];
            posts.push(post);
            post = {};
        }
        let schemaValidation = {
            name: { type: "string", optional:false, min: 10, max: 100 },
            designation: { type: "string", optional:false, max: 100 },
            company_name: { type: "string", optional:false, max: 100 },
            experience: { type: "number", optional:true, min: 1, max: 50 },
            ctc_currency: { type: "string", min: 3, max: 10 },
            ctc: { type: "number", min: 10, max: 1000 },
            ctc_type: { type: "string", min: 3, max: 10 },
            email_id: { type: "email", optional:false, min: 10, max: 100 },
            phone_number: { type: "number", optional:false },
        };
        for (var ind in posts) {
            const validationResponse = vali.validate(posts[ind], schemaValidation);
            if (validationResponse!==true) err.push({ error: validationResponse });
        }
        
        if(err.length) {
            res.status(400).json({
                message: "Validation failed.",
                error: err
            });
        } else {
            if (findDuplicateValue(rows) === true) {
                res.status(409).json({
                    message: 'Dulicate rows.'
                });
            } else {
                let sql = "INSERT INTO candidate_summary (name, designation, company_name, experience, ctc_currency, ctc, ctc_type, email_id, phone_number, linkedInLink, location) VALUE ?";
                conn.query(sql, [rows], (error, result) => {
                    if (error) {
                        res.status(400).json({
                            message: "Data not inserted.",
                            error: error
                        });
                    } else {
                        res.status(200).json({
                            message: "Data inseted.",
                            result: result.affectedRows
                        });
                    }
                });
            }
        }
    });
}

route.get('/', (req, res, next) => {
    conn.query("SELECT * FROM candidate_summary", (error, rows) => {
        if(error) {
            res.status(400).json({
                message: "No data found."
            });
        } else {
            const outputArr = [];
            let output = {};
            for(let row=0; row<rows.length; row++) {
               output = {
                "ctc":  {
                    "value" : rows[row]["ctc"],               
                    "ctcUnit": rows[row]["ctc_type"],               
                     "ctcCurrency" : rows[row]["ctc_currency"],               
                  },               
                "candidateExperience": rows[row]["experience"],               
                "company ": {               
                   "name": rows[row]["company_name"]               
                 },               
                "location" : {               
                  "city": rows[row]["location"]               
                  },               
                "linkedIn": rows[row]["linkedInLink"]
               }
               outputArr.push(output);
               output = {};
            }
            res.status(200).json({
                message: "Display all data.",
                result: outputArr
            });
        }
    });    
});

route.post('/insertExcelData', (req, res, next) => {
  insertData(req, res);
});

module.exports = route;
