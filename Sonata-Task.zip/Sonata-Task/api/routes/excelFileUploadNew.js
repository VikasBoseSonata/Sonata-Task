// This route file will read the excel file and insert the data into postgre/mysql DB
const express = require('express');
const conn = require('../models/dbConnection');
const Validator = require("fastest-validator"); //This will use to validate the datatype while insert the data into DB
const xlsx = require('read-excel-file/node');
const validator = require('mysql-validator');

const route = express.Router();
const vali = new Validator();

const insertData = function(req, res) {
    let a = xlsx('files/candidate-upload-template-new.xlsx').then((rows) => {
        /*const schemaValidation = {
            name: { type: "string", optional:false, min: 10, max: 100 },
            designation: { type: "string", optional:false, max: 100 },
            company_name: { type: "string", optional:false, max: 100 },
            experience: { type: "number", optional:true, min: 1, max: 50 },
            ctc_currency: { type: "string", min: 3, max: 10 },
            ctc: { type: "number", min: 10, max: 1000 },
            ctc_type: { type: "string", min: 3, max: 10 },
            email_id: { type: "email", optional:false, min: 10, max: 100 },
            phone_number: { type: "string", optional:false, max: 20 },
        };
        const validationResponse = vali.validate(rows, schemaValidation);
        if(validationResponse !== true) {
            return res.status(400).json({
                message: "Validation failed.",
                error: validationResponse
            });
        }*/
        
        /*let sql = "INSERT INTO candidate_summary (name, designation, company_name, experience, ctc_currency, ctc, ctc_type, email_id, phone_number, linkedInLink, location, created_date, created_by, modified_date, modified_by) VALUE ?";
        conn.query(sql, [rows], (error, result) => {
            if (error) {
                res.status(400).json({
                    message: "Data not inserted.",
                    error: error
                });
            } else {
                res.status(200).json({
                    message: "Data inseted.",
                    result: result.affectedRows
                });
            }
        });*/
    });
}

route.get('/', (req, res, next) => {
    conn.query("SELECT * FROM candidate_summary", (error, rows) => {
        if(error) {
            res.status(400).json({
                message: "No data found."
            });
        } else {
            res.status(200).json({
                message: "Display all data.",
                result: rows
            });
        }
    });    
});

route.post('/insertExcelData', (req, res, next) => {
  insertData(req, res);
});

module.exports = route;
