// This file is initilize when server executes
const express = require('express');
const bodyParser = require('body-parser');
/**
 * This function will spin up the express utiliy and allow us to use pre-define function/methods
 */
const app = express();
const excelFileRouter = require('./api/routes/excelFileUploadNew');
// const excelFileRouter = require('./api/routes/excelFileUpload');
const morgan = require('morgan');

app.use(morgan('dev'));
app.use(bodyParser.json());
app.use('/excelFileUpload', excelFileRouter);
// In case of no request handle by the any of routers then it will reach to below line 
app.use((req, res, next) => {
    const error = new Error("Not found");
    error.status = 404;
    next(error);
});
/*The below middlewear can handle all kind of error either create above error object or else using different routers
For example when we connect with the DB then the below middlewear handle those error. 
*/
app.use((error, req, res, next) => {
    res.status(error.status || 500);
    res.json({
        error: {
            message: error.message
        }
    });
});

module.exports = app;
