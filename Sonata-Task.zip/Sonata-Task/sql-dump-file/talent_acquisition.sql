-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2020 at 02:49 AM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `talent_acquisition`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidate_summary`
--

CREATE TABLE `candidate_summary` (
  `candidate_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `experience` int(3) NOT NULL,
  `ctc_currency` varchar(10) NOT NULL,
  `ctc` int(4) NOT NULL,
  `ctc_type` varchar(10) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `phone_number` varchar(100) NOT NULL,
  `linkedInLink` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` varchar(100) NOT NULL,
  `modified_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `candidate_summary`
--

INSERT INTO `candidate_summary` (`candidate_id`, `name`, `designation`, `company_name`, `experience`, `ctc_currency`, `ctc`, `ctc_type`, `email_id`, `phone_number`, `linkedInLink`, `location`, `created_date`, `created_by`, `modified_date`, `modified_by`) VALUES
(1, 'John Deo', 'CEO', 'ABC Info Tech', 15, 'INR', 20, 'LAKHS', 'JohnDeo@mail.com', '1234567890', 'https://www.linkedin.com', 'Mumbai, Maharashtra', '0000-00-00 00:00:00', 'null', '0000-00-00 00:00:00', 'null'),
(2, 'John Deo 01', 'CEO', 'ABC Info Tech', 15, 'INR', 20, 'LAKHS', 'JohnDeo@mail.com', '1234567890', 'https://www.linkedin.com', 'Mumbai, Maharashtra', '0000-00-00 00:00:00', 'null', '0000-00-00 00:00:00', 'null');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidate_summary`
--
ALTER TABLE `candidate_summary`
  ADD PRIMARY KEY (`candidate_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `candidate_summary`
--
ALTER TABLE `candidate_summary`
  MODIFY `candidate_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
